package firstscreenplay.ui;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://www.google.co.uk")
public class GoogleSearchPage extends PageObject {}
