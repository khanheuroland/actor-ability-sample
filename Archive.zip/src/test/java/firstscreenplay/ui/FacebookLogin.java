package firstscreenplay.ui;

import net.serenitybdd.screenplay.targets.Target;

public class FacebookLogin {
    public static final Target ERROR_TOOLTIP = Target.the("Error tooltip").locatedBy("");
}
