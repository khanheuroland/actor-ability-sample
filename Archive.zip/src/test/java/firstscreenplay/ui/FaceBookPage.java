package firstscreenplay.ui;


import net.serenitybdd.screenplay.targets.Target;

public class FaceBookPage {

    public static final Target MAIN_HEADING = Target.the("main heading")
            .locatedBy("div.rfloat .fcb");
    public static final Target USERNAME_FIELD = Target.the("username")
            .locatedBy("input#email");
    public static final Target PASSWORD_FIELD = Target.the("password")
            .locatedBy("input#pass");
}
