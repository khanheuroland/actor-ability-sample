package firstscreenplay.features.search;

import firstscreenplay.abilities.Authenticate;
import firstscreenplay.questions.ErrorQuestion;
import firstscreenplay.questions.PageQuestion;
import firstscreenplay.tasks.Login;
import firstscreenplay.ui.FaceBookPage;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.conditions.Check;
import net.serenitybdd.screenplay.questions.page.TheWebPage;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import firstscreenplay.tasks.OpenTheApplication;
import firstscreenplay.tasks.Search;

import static net.serenitybdd.screenplay.GivenWhenThen.*;
import static net.serenitybdd.screenplay.EventualConsequence.eventually;
import static org.hamcrest.Matchers.*;

@RunWith(SerenityRunner.class)
public class SearchByKeywordStory {

    Actor anna = Actor.named("Anna");

    @Managed(uniqueSession = true)
    public WebDriver herBrowser;

    @Before
    public void annaCanBrowseTheWeb() {
        anna.can(BrowseTheWeb.with(herBrowser))
            .can(Authenticate.LoadTestData(anna.getName()));
    }


    @Test
    public void the_default_main_heading_show_on_home_page() {
        anna.attemptsTo(
                Open.url("http://www.facebook.com")
        );

        anna.should(
                seeThat(PageQuestion.TextOfMainHeading(),
                        equalTo("Tạo tài khoản mới"))
        );
    }

    @Test
    public void show_error_message_with_invalid_credential()
    {
        givenThat(anna).wasAbleTo(Open.url("https://www.facebook.com"));
        when(anna).attemptsTo(
                Login.withEmail(anna.abilityTo(Authenticate.class).getEmail())
                        .andPassword(anna.abilityTo(Authenticate.class).getPassword())
        );
        then(anna).should(
                seeThat(ErrorQuestion.TextOfNotification(),
                        startsWith("Mật khẩu bạn đã nhập không chính xác."))
        );
    }
}