package firstscreenplay.questions;

import firstscreenplay.ui.FacebookLogin;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ErrorQuestion implements Question<String> {
    public static Question<String> TextOfNotification() {
        return new ErrorQuestion();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(FacebookLogin.ERROR_TOOLTIP).viewedBy(actor).asString();
    }
}
