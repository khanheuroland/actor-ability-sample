package firstscreenplay.questions;

import firstscreenplay.ui.FaceBookPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class PageQuestion implements Question<String> {
    public static Question<String> TextOfMainHeading() {
        return new PageQuestion();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(FaceBookPage.MAIN_HEADING)
                .viewedBy(actor)
                .asString();
    }
}
