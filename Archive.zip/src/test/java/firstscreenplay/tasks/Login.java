package firstscreenplay.tasks;

import firstscreenplay.ui.FaceBookPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;
import org.openqa.selenium.Keys;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class Login implements Task {
    private String username;
    private String password;

    public Login(String username, String password)
    {
        this.username = username;
        this.password = password;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
            Enter.theValue(username).into(FaceBookPage.USERNAME_FIELD),
            Enter.theValue(password).into(FaceBookPage.PASSWORD_FIELD)
                    .thenHit(Keys.ENTER)
        );
    }
/*
    public static Login With(String username, String password)
    {
        return instrumented(Login.class,username, password);
    }
*/
    public static LoginBuilder withEmail(String email)
    {
        return new LoginBuilder(email);
    }

    public static class LoginBuilder
    {
        private String email;
        public LoginBuilder(String email)
        {
            this.email = email;
        }

        public Login andPassword(String password)
        {
            return instrumented(Login.class, this.email, password);
        }
    }
}
