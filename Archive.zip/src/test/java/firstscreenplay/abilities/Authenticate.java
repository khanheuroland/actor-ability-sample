package firstscreenplay.abilities;

import net.serenitybdd.screenplay.Ability;
import net.serenitybdd.screenplay.Actor;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Properties;

public class Authenticate implements Ability {
    private String Email;
    private String Password;

    public String getEmail()
    {
        return this.Email;
    }

    public String getPassword()
    {
        return this.Password;
    }

    public Authenticate(String username, String password)
    {
        this.Email = username;
        this.Password = password;
    }

    public static Authenticate LoadTestData(String actorName)
    {
        try {

            Reader dataReader = new FileReader("/Users/admin/Downloads/apache-maven-3.6.3/bin/firstscreenplay/src/test/resources/TestData/user."
                    +actorName.toLowerCase()+".properties");
            Properties dataProperties = new Properties();
            dataProperties.load(dataReader);

            String Email = dataProperties.getProperty("email");
            String Password = dataProperties.getProperty("password");

            return new Authenticate(Email, Password);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return new Authenticate("","");
    }

    public Authenticate as(Actor actor)
    {
        return this;
    }
}
